How to Run Project
1. Download and Unzip the file on your local system copy bbdms.
2. Put bbdms folder inside root directory

Database Configuration
Open phpmyadmin "http://localhost/phpmyadmin"
Create Database bbdms
Import database bbdms.sql (available inside zip package)
Open Your browser put inside browser “http://localhost/bbdms”

For Admin Panel
Open Your browser put inside browser “http://localhost/bbdms/admin”

Login Details for admin :
Username: admin
Password: Test@12345