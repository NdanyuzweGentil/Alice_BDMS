  
  
  <footer class="py-5 bg-inverse">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Blood Bank Information Management System 2021</p>
        </div>
        <!-- /.container -->
    </footer>