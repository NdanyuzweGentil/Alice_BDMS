-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2021 at 02:37 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbdms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', '5c428d8875d2948607f3e3fe134d71b4', '2021-03-26 08:43:28');

-- --------------------------------------------------------

--
-- Table structure for table `tbladdress`
--

CREATE TABLE `tbladdress` (
  `id` int(11) NOT NULL,
  `DonorAddress` varchar(255) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladdress`
--

INSERT INTO `tbladdress` (`id`, `DonorAddress`, `PostingDate`) VALUES
(1, 'Kicukiro', '2021-03-26 08:10:20'),
(2, 'Gasabo', '2021-03-26 08:10:32'),
(3, 'Nyarugenge', '2021-03-26 08:10:44'),
(4, 'Nyamata', '2021-03-26 08:27:39'),
(5, 'Muyumbo', '2021-03-26 08:27:47'),
(7, 'Ruyenzi', '2021-03-26 08:28:31'),
(8, 'Nyanza', '2021-07-08 13:44:32');

-- --------------------------------------------------------

--
-- Table structure for table `tblblooddonars`
--

CREATE TABLE `tblblooddonars` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `MobileNumber` char(11) DEFAULT NULL,
  `EmailId` varchar(100) DEFAULT NULL,
  `Gender` varchar(20) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `BloodGroup` varchar(20) DEFAULT NULL,
  `Bloodlitre` varchar(10) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Message` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblblooddonars`
--

INSERT INTO `tblblooddonars` (`id`, `FullName`, `MobileNumber`, `EmailId`, `Gender`, `Age`, `BloodGroup`, `Bloodlitre`, `Address`, `Message`, `PostingDate`, `status`) VALUES
(1, 'Turatsinze Junior', '0785039498', 'junior@gmail.com', 'Male', 27, 'O-', '0.5l', 'Kicukiro', ' Thanks for this services, I\'m interested in giving the blood', '2021-03-30 20:14:16', 1),
(2, 'Dushime Yves', '0785039498', 'dushimeyves@dfdsf.com', 'Male', 34, 'AB-', '1l', 'Gasabo', ' Thanks for this services, I\'m interested in giving the blood', '2021-03-26 08:43:28', 1),
(3, 'Kamari Anaclet', '0785039498', 'kamari@gmail.com', 'Male', 23, 'A+', '0.25l', 'Nyarugenge', ' Thanks for this services, I\'m interested in giving the blood', '2021-03-26 08:43:28', 1),
(4, 'Marriam Kagaju', '0785039498', 'kagaju@gmail.com', 'Female', 26, 'AB-', '1l', 'Kicukiro', ' Thanks for this services, I\'m interested in giving the blood', '2021-03-26 08:43:28', 1),
(5, 'Katushabe Annet', '0785039498', 'annet@test.com', 'Female', 32, 'A-', '0.5l', 'Gasabo', ' Thanks for this services, I\'m interested in giving the blood', '2021-03-26 08:43:28', 1),
(6, 'Donat NSHIMIYIMANA', '0785039498', 'donatnshimiyimana@gmail.com', 'Male', 25, 'A-', '0.25l', 'Nyarugenge', ' I\'m interested in giving my blood', '2021-03-26 06:58:17', 1),
(7, 'Ndanyuzwe Gentil', '0788663304', 'ndanyuzwegentil@gmail.com', 'Male', 25, 'A-', '0.25l', 'Ruyenzi', ' I want to donor my blood.\r\nThanks', '2021-03-26 08:37:32', 1),
(8, 'Mukamutara Ruth', '0784039381', 'mukamutararuth@gmail.com', 'Female', 24, 'O-', '0.5l', 'Nyamata', ' Thanks for this services, I\'m interested in giving the blood', '2021-03-26 08:43:28', 1),
(9, 'Peter', '0780383403', 'peter@gmail.com', 'Male', 20, 'AB-', '1l', 'Nyanza', ' I\'m interested to donate a blood', '2021-07-08 13:50:32', 1),
(12, 'Olivier', '0789928482', 'olivier@gmail.com', 'Male', 19, 'A+', '0.5l', 'Gasabo', ' I\'m interested to donate a blood', '2021-08-23 11:31:19', 1),
(13, 'Tom', '0789928480', 'tom@gmail.com', 'Male', 22, 'A+', '2l', 'Gasabo', ' I want to give blood', '2021-08-23 12:00:14', 1),
(14, 'Karamage', '0789922882', 'karamage18@gmail.com', 'Male', 30, 'O-', '1 litre', 'Muyumbo', ' Thanks for The service of blood donation', '2021-08-23 12:24:10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblbloodgroup`
--

CREATE TABLE `tblbloodgroup` (
  `id` int(11) NOT NULL,
  `BloodGroup` varchar(20) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbloodgroup`
--

INSERT INTO `tblbloodgroup` (`id`, `BloodGroup`, `PostingDate`) VALUES
(2, 'AB-', '2021-03-26 08:43:28'),
(3, 'O-', '2021-03-26 08:43:28'),
(4, 'A-', '2021-03-26 08:43:28'),
(5, 'A+', '2021-03-26 08:43:28'),
(6, 'AB+', '2021-03-26 08:43:28'),
(7, 'O+', '2021-08-23 12:29:32');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusinfo`
--

CREATE TABLE `tblcontactusinfo` (
  `id` int(11) NOT NULL,
  `Address` tinytext DEFAULT NULL,
  `EmailId` varchar(255) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactusinfo`
--

INSERT INTO `tblcontactusinfo` (`id`, `Address`, `EmailId`, `ContactNo`) VALUES
(1, 'KG 203 St, Kigali																							', 'info@test.com', '+2507873226');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusquery`
--

CREATE TABLE `tblcontactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `ContactNumber` char(11) DEFAULT NULL,
  `Message` longtext DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactusquery`
--

INSERT INTO `tblcontactusquery` (`id`, `name`, `EmailId`, `ContactNumber`, `Message`, `PostingDate`, `status`) VALUES
(1, 'Anuj Kumar', 'webhostingamigo@gmail.com', '2147483647', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '2017-06-18 10:03:07', 1),
(2, 'caasda', 'webhostingamigo@gmail.com', '42342342', 'drftghjk', '2017-06-30 21:17:09', 1),
(3, 'caasda', 'webhostingamigo@gmail.com', '42342342', 'drftghjk', '2017-06-30 21:21:30', NULL),
(4, 'te', 'sdfsdf@gmail.com', '75787875545', 'sfsdf sdg hs h sh', '2017-07-01 07:19:36', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `type`, `detail`) VALUES
(2, 'Why Become Donor', 'donor', '<p class=\"MsoNormal\"><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">One of the biggest obstacles to organ\r\ntransplantation is getting individuals to register to become organ donors\r\nbefore they are faced with a tragic situation. Consider these reasons why you\r\nshould be an organ donor.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">1. Organ donation is an opportunity to\r\nhelp others.</span></b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">&nbsp;People who are on an organ\r\nwaiting list typically have end-stage organ disease that significantly impacts\r\ntheir quality of life and maybe near the end of their life. Receiving an organ\r\ncan become a life-changing event for these people. It can also help a family\r\nwork through the grieving process and deal with their loss by knowing their\r\nloved one is helping save the lives of others.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">2. The organ waiting list is always\r\nlong.</span></b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">&nbsp;Every day, there are\r\napproximately&nbsp;<a href=\"https://www.organdonor.gov/statistics-stories/statistics.html\" target=\"_blank\"><span style=\"color: windowtext;\">107,000 people</span></a>&nbsp;on the\r\nwaiting list nationally for an organ.&nbsp;<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">3.&nbsp;People are dying while waiting\r\nfor an organ.&nbsp;</span></b><span style=\"mso-bidi-font-size:12.0pt;\r\nline-height:107%;mso-bidi-font-family:&quot;Times New Roman&quot;\">&nbsp;Each day&nbsp;<a href=\"https://www.organdonor.gov/statistics-stories/statistics.html\" target=\"_blank\"><span style=\"color: windowtext;\">17 people in the United States die</span></a>&nbsp;waiting\r\nfor a transplant.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">4. Nebraska needs more organ\r\ndonors.&nbsp;</span></b><span style=\"mso-bidi-font-size:12.0pt;line-height:\r\n107%;mso-bidi-font-family:&quot;Times New Roman&quot;\">In Nebraska alone, there are\r\napproximately&nbsp;<a href=\"https://optn.transplant.hrsa.gov/data/view-data-reports/state-data/\" target=\"_blank\"><span style=\"color: windowtext;\">350&nbsp;people waiting for an organ</span></a>.\r\nOnly about&nbsp;<a href=\"https://lexch.com/news/hispanic-latinos-are-among-the-60-percent-waiting-for-an-organ-transplant-but-few-are/article_1e829b60-0e27-11eb-b9d9-c7e72e1ccfe6.html#:~:text=It\'s%20not%20just%20a%20Hispanic,percent%20are%20registered%20as%20donors.\" target=\"_blank\"><span style=\"color: windowtext;\">58 percent of Nebraskans</span></a>&nbsp;have&nbsp;registered\r\nas organ donors. In 2020&nbsp;<a href=\"https://omaha.com/lifestyles/health-med-fit/live-on-nebraska-sees-record-for-number-of-organ-and-tissue-donations/article_151a9f10-60dd-11eb-a77d-1beffdbec0d3.html\" target=\"_blank\"><span style=\"color: windowtext;\">72 people in Nebraska who died\r\ndonated organs</span></a>, resulting in 214 organ transplants.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">5. One organ donor can help multiple\r\npeople.</span></b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">&nbsp;One organ donor has the potential\r\nto save eight lives.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">6. Living donors fill a crucial\r\nneed.&nbsp;</span></b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">&nbsp;A living donor can donate a\r\nkidney or a portion of their liver to a friend or family member or even\r\naltruistically and continue to live a normal life with very little\r\nrestrictions. People waiting for a kidney transplant make up more than 80\r\npercent of people on the organ waiting list and people waiting for a liver\r\ntransplant make up approximately 12 percent.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">7. Organ donation can be a rewarding\r\nand positive experience.</span></b><span style=\"mso-bidi-font-size:12.0pt;\r\nline-height:107%;mso-bidi-font-family:&quot;Times New Roman&quot;\">&nbsp;It can help a\r\nfamily work through the grieving process and deal with their loss by knowing\r\ntheir loved one is helping save the lives of others.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">8. There are no age exclusions to\r\ndonate.</span></b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">&nbsp;If you are otherwise healthy,\r\nmany of your organs could still be viable for an organ donation. The transplant\r\nsurgeon evaluates the organs and decides whether they are suitable on a\r\ncase-by-case basis.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">9. Very few medical conditions\r\ndisqualify you from donating your organs</span></b><span style=\"mso-bidi-font-size:\r\n12.0pt;line-height:107%;mso-bidi-font-family:&quot;Times New Roman&quot;\">. It may be\r\ndetermined that certain organs are not suitable for transplantation, but other\r\ntissues and organs may be fine. Simply put, a disease in one organ does not\r\npreclude other organs from being donated.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><b><span style=\"mso-bidi-font-size:12.0pt;line-height:107%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;\">10. Most religions support organ\r\ndonation.&nbsp;</span></b><span style=\"mso-bidi-font-size:12.0pt;line-height:\r\n107%;mso-bidi-font-family:&quot;Times New Roman&quot;\">This includes Catholics,\r\nProtestants, Islam, and most branches of Judaism see&nbsp;it as the final\r\nact of love and generosity toward others. If you are unsure, the federal\r\nwebsite,&nbsp;<a href=\"https://www.organdonor.gov/about/donors/religion.html\" target=\"_blank\"><span style=\"color: windowtext;\">OrganDonor.gov provides religious\r\nviews on organ donation and transplantation</span></a>&nbsp;by denomination.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><br></p>'),
(3, 'About Us ', 'aboutus', '																																																																						<p class=\"MsoNormal\" style=\"margin: 12pt 0in 0.0001pt 0.5in; font-size: 14px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; line-height: 15.75pt;\"><b><span style=\"font-size: 10.5pt; font-family: Helvetica, sans-serif;\">BLOOD BANK INFORMATION MANAGEMENT SYSTEM</span></b><span style=\"font-size: 10.5pt; font-family: Helvetica, sans-serif;\">,&nbsp;the objective of the work&nbsp;is to save lives by&nbsp;helping Blood donors to donate blood and help doctors from different hospital to request blood bags to the blood bank as well as help to generate some reports.&nbsp;This system gives the ability to the donors to donate blood easily at large numbers and help doctors to request the blood bags in the store to serve patients.<o:p></o:p></span></p><p class=\"MsoNormal\" style=\"margin: 12pt 0in 0.0001pt 0.5in; font-size: 14px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; line-height: 15.75pt;\"><span style=\"font-size: 12pt; font-family: &quot;Times New Roman&quot;, serif;\">Blood transfusion safety remains an important public health concern; using an online blood bank management system, blood transfusion safety is expected to be enhanced or improved risks on improper blood donors’ documentation; misplace of records can be minimized or totally avoided and tracing the nearest blood bank can save a life in the processes involving blood bag collection, storage, and inventory.</span><span style=\"font-size: 10.5pt; font-family: Helvetica, sans-serif;\"><br><o:p></o:p></span></p><p class=\"MsoNormal\" style=\"margin: 12pt 0in 0.0001pt 0.5in; font-size: 14px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; line-height: 15.75pt;\"><span style=\"font-size: 10.5pt; font-family: Helvetica, sans-serif;\">This system gives the ability to the donors to donate blood easily in large numbers and help&nbsp;</span><span style=\"font-family: Helvetica, sans-serif; font-size: 10.5pt;\">doctors to request the blood bags in the store to serve patients.</span></p><p class=\"MsoNormal\" style=\"margin: 12pt 0in 0.0001pt 0.5in; font-size: 14px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; line-height: 15.75pt;\"><span style=\"font-size: 12pt; font-family: &quot;Times New Roman&quot;, serif;\">Blood transfusion safety remains an important public health concern; using an online blood bank management system, blood transfusion safety is expected to be enhanced or improved risks on improper blood donors’ documentation; misplace of records can be minimized or totally avoided, and tracing the nearest blood bank can save a life in the processes involving blood bag collection, storage, and inventory.</span><span style=\"font-size: 10.5pt; font-family: Helvetica, sans-serif;\"><o:p></o:p></span></p><p class=\"MsoNormal\" style=\"margin: 12pt 0in 0.0001pt 0.5in; font-size: 14px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; line-height: 15.75pt;\"><span style=\"font-family: Helvetica, sans-serif;\">The objective of the work&nbsp;is to save lives by&nbsp;helping Blood donors to donate blood and help doctors from different hospitals to request blood bags to the blood bank as well as help to generate some reports.&nbsp;This system gives the ability to the donors to donate blood easily in large numbers and help doctors to request the blood bags in the store to serve patients.</span></p><p class=\"MsoNormal\" style=\"margin: 12pt 0in 0.0001pt 0.5in; font-size: 14px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; line-height: 15.75pt;\"><span style=\"font-family: Helvetica, sans-serif; font-size: 1em;\">This system gives the ability to the donors to donate blood easily in large numbers and help doctors to request the blood bags in the store to serve patients.</span></p>\r\n										\r\n										\r\n										\r\n										\r\n										\r\n										\r\n										');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbladdress`
--
ALTER TABLE `tbladdress`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblblooddonars`
--
ALTER TABLE `tblblooddonars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbloodgroup`
--
ALTER TABLE `tblbloodgroup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbladdress`
--
ALTER TABLE `tbladdress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblblooddonars`
--
ALTER TABLE `tblblooddonars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tblbloodgroup`
--
ALTER TABLE `tblbloodgroup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
